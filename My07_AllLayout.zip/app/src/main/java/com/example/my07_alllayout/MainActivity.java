package com.example.my07_alllayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button btnChange1, btnChange2;
    ImageView imageView1, imageView2, imageView3, img1, img2;
    int selImg1 = 2;
    int selImg2 = 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);

        //동적으로 첫번쨰 이미지만 보이게 초기화한다.
        imageView1.setVisibility(View.VISIBLE);
        imageView2.setVisibility(View.GONE);
        imageView3.setVisibility(View.GONE);
        btnChange1 = findViewById(R.id.btnChange1);
        btnChange1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selImg1==1){
                    imageView1.setVisibility(View.VISIBLE);
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.GONE);
                    selImg1 =2;
                }else if(selImg1 == 2){
                    imageView1.setVisibility(View.GONE);
                    imageView2.setVisibility(View.VISIBLE);
                    imageView3.setVisibility(View.GONE);
                    selImg1 =3;
                }else if(selImg1 == 3){
                    imageView1.setVisibility(View.GONE);
                    imageView2.setVisibility(View.GONE);
                    imageView3.setVisibility(View.VISIBLE);
                    selImg1 =1;
                }

            }
        });
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img1.setVisibility(View.VISIBLE);
        img2.setVisibility(View.GONE);
        btnChange2 = findViewById(R.id.btnChange2);
        btnChange2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selImg2==1){
                    img1.setVisibility(View.VISIBLE);
                    img2.setVisibility(View.GONE);

                    selImg2 =2;
                }else if(selImg2 == 2){
                    img1.setVisibility(View.GONE);
                    img2.setVisibility(View.VISIBLE);
                    selImg2 =1;
                }
            }
        });

    }
}