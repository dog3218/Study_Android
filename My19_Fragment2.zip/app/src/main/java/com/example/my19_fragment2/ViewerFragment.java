package com.example.my19_fragment2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ViewerFragment extends Fragment {
    ImageView imageView2;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_viewer,
                container, false);

        imageView2 = rootView.findViewById(R.id.imageView2);
        return rootView;
    }

    public void imageChange(int resId){
        /*if(state==1){
            imageView2.setImageResource(R.drawable.dream01);
        }else if(state==2){
            imageView2.setImageResource(R.drawable.dream02);
        }*/
        imageView2.setImageResource(resId);
    }
}
