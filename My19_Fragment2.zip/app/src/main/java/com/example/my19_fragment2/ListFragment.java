package com.example.my19_fragment2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ListFragment extends Fragment {
   MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_list,
                container, false);
        activity = (MainActivity) getActivity();
        rootView.findViewById(R.id.btnImg1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.imageSelected(R.drawable.dream01);
            }
        });
        rootView.findViewById(R.id.btnImg2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.imageSelected(R.drawable.dream01);
            }
        });
        return rootView;
    }
}
