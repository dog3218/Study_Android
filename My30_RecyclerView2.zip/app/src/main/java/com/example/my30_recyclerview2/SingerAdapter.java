package com.example.my30_recyclerview2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SingerAdapter extends RecyclerView.Adapter<SingerAdapter.ViewHolder>
implements OnSingerItemClickListener {
    private static final String TAG = "main: SingerAdapter";

    //3)리스너 선언 : 메인에서 사용하는 것
   OnSingerItemClickListener listener;

    //메인에서 넘겨받을 거 받아놓기
    Context context;
    ArrayList<SingerDTO> dtos;

    LayoutInflater inflater;

    //생성자를 만들어서 연결결

    public SingerAdapter(Context context, ArrayList<SingerDTO> dtos) {
        this.context = context;
        this.dtos = dtos;
        inflater = LayoutInflater.from(this.context);
    }

    //=================================================================
    //메소드는 여기 만든다.
    //dtos에 dto 추가하는 메소드
    public void addDto(SingerDTO dto){
        dtos.add(dto);
    }

    //dtos의 특정 위치의 dto를 삭제하는 메소드
    public void delDto(int position){
        dtos.remove(position);
    }

    //4)메인에서 클릭리스너를 클릭했을 때 위 3)에서 선언한 리스너와 연결
    public void setOnItemClickListener(OnSingerItemClickListener listener){
        this.listener = listener;
    }

    //메인에서 클릭한 위치에 있는 dto 가져오기
    public SingerDTO getItem(int position){

        return dtos.get(position);
    }


    //=================================================================

   //1)화면을 인플레이트 시키면서 클릭리스너를 달고 들어간다.
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View itemView = inflater.inflate(R.layout.singerview, parent, false);

        return new ViewHolder(itemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Log.d(TAG, "onBindViewHolder: "+position);
        //dtos에 있는 데이터를 각각 불러온다.
        SingerDTO dto = dtos.get(position);

        //불러온 데이터를 viewHolder에 만들어 놓은 setDto()를 이용하여
        //세팅시킨다.
        holder.setDTO(dto);

        //리사이클러뷰에 항목을 선택했을 때 리스너를 통해 그 항목을 가져올 수 있다.
        /*holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SingerDTO dto1 = dtos.get(position);
                Toast.makeText(context, "이름 : "+ dto1.getName(), Toast.LENGTH_SHORT).show();
            }
        });*/
        //쓰레기통 이미지 클릭시 해당 dto 삭제
        holder.ivTrash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delDto(position);
                notifyDataSetChanged();

            }
        });
    }

    //dtos에 저장된 dto 개수
    @Override
    public int getItemCount() {
        return dtos.size();
    }

    //인터페이스에 정의된 메소드 구현
    //5)뷰홀더의 클릭리스너를 실행한 후 position을 얻어 메인으로 보낸다.
    @Override
    public void onItemClick(ViewHolder holderM, View view, int position) {
        if(listener !=null){
            listener.onItemClick(holderM, view, position);
        }
    }

    // 3. xml 파일에서 사용된 모든 변수를 adapter에서 클래스로 선언한다
    public class ViewHolder extends RecyclerView.ViewHolder{
        //singerview.xml에 사용된 모든 위젯을 정의한다.
        TextView tvName, tvMobile;
        ImageView ivImage, ivTrash;
        LinearLayout parentLayout;

        //singerview에 정의한 아이디를 찾아 연결시킨다.(생성자, 클릭리스너)
        public ViewHolder(@NonNull View itemView, OnSingerItemClickListener listener) {
            super(itemView);

        parentLayout = itemView.findViewById(R.id.parentLayout);
        tvName = itemView.findViewById(R.id.tvName);
        tvMobile = itemView.findViewById(R.id.tvMobile);
        ivImage = itemView.findViewById(R.id.ivImage);
        ivTrash = itemView.findViewById(R.id.ivTrash);

        //2) 클릭리스너를 만들어준다.
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = getAdapterPosition();
                if(listener != null){
                    listener.onItemClick(ViewHolder.this,
                            view, position);//포지션 자리에 바로 getAdapterPosition() 넣어줘도 됨
                }
            }
        });

         }

    //4.함수를 만들어서 singerview에 데이터를 연결시킨다.
    public void setDTO(SingerDTO dto){
        tvName.setText(dto.getName());
        tvMobile.setText(dto.getMobile());
        ivImage.setImageResource(dto.getResId());

    }
}
}





