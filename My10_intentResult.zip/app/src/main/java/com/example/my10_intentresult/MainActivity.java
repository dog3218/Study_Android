package com.example.my10_intentresult;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        TextView tvMain;
        int ReqCode = 1004;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvMain = findViewById(R.id.tvMain);
        findViewById(R.id.btnMain).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PersonDTO personDTO1 = new PersonDTO("cho", 1111);

                //1/서브창을 띄우고 데이터를 넘긴다. 인텐트 조공

                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                intent.putExtra("id", "PARK");
                intent.putExtra("pw", 1234);
                intent.putExtra("personDTO1", personDTO1);
                startActivityForResult(intent, ReqCode);
            }
        });
    }
    //4.서브에서 보낸 데이터 받기 : 정해져 잇음 반드시 오버라이드 시켜야함

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //                               1004               -1         서브에서 넘겨준 값
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == ReqCode){//서브화면에서 받은것
            if(data != null){
                    String key = data.getStringExtra("key");
                    tvMain.setText(key);
            }


        }else if(requestCode == 1005){

        }


    }
}