package com.example.my10_intentresult;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {
    TextView tvSub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        tvSub = findViewById(R.id.tvSub);
        //2.메인에서 넘겨준 데이터 받기-넘어온게 있으면 Null이 아닐 것
        Intent intent = getIntent();
        if(intent != null){
            String id= intent.getStringExtra("id");
            int pw= intent.getIntExtra("pw", 9999);
            PersonDTO personDTO1 =
                    (PersonDTO) intent.getSerializableExtra("personDTO1");
            tvSub.setText("id : "+ id+"\n"+"pw : "+pw);
            //기존에 써져있던 데이터를 모두 지운다.
            tvSub.append("\nid : " + personDTO1.getId()+ "\n pw: "+personDTO1.getPw());
        }


        findViewById(R.id.btnSub).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //3.받은 데이터를 다시 Main으로 보내기
                Intent reIntent = new Intent();
                reIntent.putExtra("key", tvSub.getText().toString()+"ㅜㅜㅜ");
                //정상적으로 종료가 되었음을 알려줌
                setResult(RESULT_OK, reIntent);
                finish();
                            }
        });
    }

}