package com.example.my10_intentresult2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {
    TextView tvSub;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);
        tvSub = findViewById(R.id.tvSub);
        Intent intent = getIntent();
        if(intent != null){
            String id = intent.getStringExtra("id");
            int pw = intent.getIntExtra("pw", 9999);
            tvSub.setText("id : "+ id+"\npw : "+pw);
        }

        findViewById(R.id.btnSub).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent reIntent = new Intent();
            reIntent.putExtra("key", tvSub.getText().toString());
            setResult(RESULT_OK, reIntent);

                finish();
            }
        });

    }
}