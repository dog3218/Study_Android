package com.example.my13_service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {
    public MyService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate: 실행됨");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy: 실행됨");
    }

    private static final String TAG = "main:MyService";//흐름을 볼 수 있는 마커 역할

    //서비스가 실행되면 무조건  onStartCommand를 실행함
    @Override//             메인에서 넘겨준 intent, flag, 실행될 떄 보이는 숫자
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand: "+flags+", "+startId);
        //flag 는 이 메소드의 표시
        // startId 는 이 메소드의 시작 횟수-종료되면 초기화됨

        //비정상적인 종료일 경우 재시작해서 정상적으로 만든다.
        if(intent==null){
            return Service.START_STICKY;
        }else{
            processCommand(intent);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    private void processCommand(Intent intent) {
        String name = intent.getStringExtra("name");
        String command = intent.getStringExtra("command");
        Log.d(TAG, "processCommand: "+name+", "+command);//데이터 잘 들어오는지 수시로 확인하자.
        for(int i =0; i<5; i++){
            try {
                Thread.sleep(1000);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
            Log.d(TAG, "Waiting" + (i + 1) + " seconds...");//안전하게 괄호로 감싸주자
            Intent reIntent = new Intent(getApplicationContext(), MainActivity.class);
            reIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            reIntent.putExtra("key", name+command+"**");


        }

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }



}