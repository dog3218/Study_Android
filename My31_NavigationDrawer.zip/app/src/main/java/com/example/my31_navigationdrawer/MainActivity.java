package com.example.my31_navigationdrawer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener {

    Toolbar toolbar;
    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;

    FloatingActionButton fab;
    DrawerLayout draw_layout;
    FrameLayout contain;
    NavigationView nav_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nav_view = findViewById(R.id.nav_view);
        //implement Listener 부를 때는 반드시 아래와 같이 해야함함
        nav_view.setNavigationItemSelectedListener(this);//셋네비게이션아템셀렉티드리스너

        //toolbar 적용 : theme 에 NoActionBar로 번경
        toolbar= findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        draw_layout = findViewById(R.id.draw_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, draw_layout, toolbar, R.string.drawer_open
                ,R.string.drawer_close);
        draw_layout.addDrawerListener(toggle);
        toggle.syncState();

        //프래그먼트를 생성해서 프레임 레이아웃을 초기화시킨다
        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();

        getSupportFragmentManager().beginTransaction().replace(R.id.contain, fragment1).commit();

        //헤드 드로어에 접근해서 로그인 정보 표시하기
        int userLevel = 0; //관리자 : 0, 일반유저 : 1 =>DB에
        String loginID = "BlackPink"; // 관리자ID : BlackPink , 일반유저ID : BTS
        View headerView = nav_view.getHeaderView(0);
        //TextView
        TextView navloginId = headerView.findViewById(R.id.loginID);
        navloginId.setText("반갑습니다"+loginID+"님!!");
        //ImageView
        ImageView loginImage = headerView.findViewById(R.id.loginImage);
        //loginImage.setImageResource(R.drawable.dream03);
        //Glide 이용해서 이미지 둥글게 만들기
        Glide.with(this)
                //.load(R.drawable.dream03)
                .load("https://2.bp.blogspot.com/-JFJateB8ryI/Vvo9E-_gSVI/AAAAAAAAtHg/Trltex74L6EUs64PNYDVapeiKG5lrQxVg/s1600/3.gif")
                .circleCrop()
                .into(loginImage);

        if(userLevel ==0){
            nav_view.getMenu().findItem(R.id.communi).setVisible(true);
        }else{
            nav_view.getMenu().findItem(R.id.communi).setVisible(false);
        }


        //플로팅버튼이 클릭되었을때
        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action"
                , Snackbar.LENGTH_LONG).setAction("Action", null).show();
            }
        });

   }

   //메뉴에 있는 아이템이 선택되었을때
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        //클릭한 아이템의 아이디를 얻음
        int id = item.getItemId();
        if(id==R.id.nav_home){
            onFragmentSelected(0);
        }else if(id==R.id.nav_gallery){
            onFragmentSelected(1);
        }else if(id==R.id.nav_slideshow){
            onFragmentSelected(2);
        }else if(id==R.id.nav_tools){
            onFragmentSelected(3);
        }else if(id==R.id.nav_share){
            onFragmentSelected(4);
        }else if(id==R.id.nav_Send){
            onFragmentSelected(5);
        }

        //메뉴 선택 후 드로어가 사라지게 한다.
        draw_layout.closeDrawer(GravityCompat.START);

        return true;
    }

    private void onFragmentSelected(int position) {
        Fragment curFragment = null;
        if(position==0){
            curFragment=fragment1;
            toolbar.setTitle("첫번째화면");
        }else if(position==1){
            curFragment=fragment2;
            toolbar.setTitle("두번째화면");
        }else if(position==2){
            curFragment=fragment3;
            toolbar.setTitle("세번째화면");
        }else if(position==3){
            curFragment=fragment1;
            toolbar.setTitle("네번째화면");
        }else if(position==4){
            curFragment=fragment2;
            toolbar.setTitle("다섯번째화면");
        }else if(position==5){
            curFragment=fragment3;
            toolbar.setTitle("여섯번째화면");
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contain,curFragment).commit();

    }

    //뒤로가기를 눌렀을 때 드로어 창이 열려있으면 닫고, 아니면 그냥 뒤로가기 작업하기


    @Override
    public void onBackPressed() {
        if(draw_layout.isDrawerOpen(GravityCompat.START)){//열려있으면
            draw_layout.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();//이건 원래 하던일
        }


    }
}