package com.example.my18_fragment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    MainFragment mainFragment;
    SubFragment subFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*mainFragment = (MainFragment) getSupportFragmentManager().
                findFragmentById(R.id.mainFragment);*/
        mainFragment = new MainFragment();
        subFragment = new SubFragment();

        //메인화면에 프래그먼트 초기화
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contain, mainFragment).commit();

    }

    //프래그먼트에서 접근할 수 있게 만든 메소드--fragment에서 바로 띄울 수 있지만 잘안됨
    public void onFragmentChange(int state ){
        if(state==1) {
            //화면을 서브 프래그먼트로 교체 : 메인프래그먼트 버튼 눌림
            getSupportFragmentManager().beginTransaction().replace(R.id.contain, subFragment).commit();
        }else if(state==2) {
            //화면을 메인 프래그먼트로 교체 : 서브프래그먼트 버튼 눌림
            getSupportFragmentManager().beginTransaction().replace(R.id.contain, mainFragment).commit();
        }

    }
}