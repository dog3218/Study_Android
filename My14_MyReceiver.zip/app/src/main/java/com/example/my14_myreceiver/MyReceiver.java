package com.example.my14_myreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyReceiver extends BroadcastReceiver {
    private static final String TAG = "main:MyReceiver";

    //데이터의 날짜형태를 내가 원하는 형태로 변형시키기 위한 변수
    public SimpleDateFormat dateFormat =
            new SimpleDateFormat("yyyy-MM-DD HH:mm:ss");


    //background에서 대기하다가 자신에게 데이터가 오면 실행
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive: 호출됨");

        //내부적으로 데이터를 저장할 수 있는 객체 : Bundle
        Bundle bundle = intent.getExtras();
        SmsMessage[] messages =  parseSmsMessage(bundle);

        if(messages != null & messages.length >0){
            Log.d(TAG, "onReceive: SMS를 수신하였습니다.");

            //보낸 사람 전화번호
            String sender = messages[0].getOriginatingAddress();
            Log.d(TAG, "sender : "+sender);
            //보낸 날짜와 시간
            Date receivedDate = new Date(messages[0].getTimestampMillis());
            Log.d(TAG, "receivedDate: "+receivedDate);

            //메시지 내용
            String content = messages[0].getMessageBody();
            Log.d(TAG, "content: "+content );

            //인텐트 생성, 데이터를 넣어 액티비티로 보내기
            Intent disIntent = new Intent(context, SmsDisActivity.class);
            //액티비티가 아닌 곳에서 인텐트를 만들때 flag_activity_new_task를
            //플래그에 추가해야 한다.********************
            disIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                    //INGLE_TOP은 똑같은 화면이 이미 띄워져있는 경우 그 화면을 재사용한다
                    //재사용하는 화면에 데이터 갱신을 위해 onNewIntent를 오버라이드해야함
                                Intent.FLAG_ACTIVITY_SINGLE_TOP);
            disIntent.putExtra("sender", sender);
            disIntent.putExtra(("receivedDate"),dateFormat.format(receivedDate));
            disIntent.putExtra("content", content);
            context.startActivity(disIntent);
        }
    }


    private SmsMessage[] parseSmsMessage(Bundle bundle) {
        Object[] objs = (Object[]) bundle.get("pdus");
        SmsMessage[] messages = new SmsMessage[objs.length];

        for(int i=0;i<objs.length; i++){
            if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){//API 23이상이면
                String format = bundle.getString("format");
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i], format);
            }else{//API 23 낮으면
                messages[i] = SmsMessage.createFromPdu((byte[]) objs[i]);

            }
        }
        return messages;

    }
}