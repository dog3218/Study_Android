package com.example.my14_myreceiver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SmsDisActivity extends AppCompatActivity {
    Button btn1;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_dis);
        btn1 = findViewById(R.id.btn1);
        textView = findViewById(R.id.textView);

        //MyReceiver에서 보낸 인텐트 받기
        Intent disIntent = getIntent();
        processIntent(disIntent);

        //닫기버튼
        findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            finish();
            }
        });
    }
    private void processIntent(Intent disIntent){
        String sender = disIntent.getStringExtra("sender");
        String receivedDate = disIntent.getStringExtra(("receivedDate"));
        String content = disIntent.getStringExtra("content");
        if(sender != null){
            btn1.setText(sender+"가 보낸 문자 수신");
            textView.setText("["+receivedDate+"]\n"+content);
        }
    }

    //기존화면을 사용하고자 할 때 onCreate()는 사용 못함
    //onNewIntent() 메소드를 오버라이드하여 새로운 데이터(Intent)를 받아
    //화면에 데이터를 갱신한다.-화면을 재사용할 때

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        processIntent(intent);
    }
}