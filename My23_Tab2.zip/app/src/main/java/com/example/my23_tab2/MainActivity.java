package com.example.my23_tab2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;//그냥 안드로이드로 하면 안됨 x를 써야함

import android.os.Bundle;
import android.util.Log;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "main:MainActivity";

    Toolbar toolbar;
    TabLayout tabs;
    Fragment1 fragment1;
    Fragment2 fragment2;
    Fragment3 fragment3;

    Fragment selFragment = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //내가만든 툴바를 액션바로 지정
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //기존 타이틀  글자가 안보이게 한다.
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);

        //프래그먼트 생성
        fragment1 = new Fragment1();
        fragment2 = new Fragment2();
        fragment3 = new Fragment3();

        //먼저 처음화면에 프래그먼트1이 보이게 하기
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.contain, fragment1).commit();

        //tab생성
        tabs = findViewById(R.id.tabs);
        tabs.addTab(tabs.newTab().setText("통화기록"));
        tabs.addTab(tabs.newTab().setText("스팸기록"));
        tabs.addTab(tabs.newTab().setText("연락처"));
        tabs.addTab(tabs.newTab().setText("통화기록"));
        tabs.addTab(tabs.newTab().setText("스팸기록"));
        tabs.addTab(tabs.newTab().setText("연락처"));
        tabs.addTab(tabs.newTab().setText("통화기록"));
        tabs.addTab(tabs.newTab().setText("스팸기록"));
        tabs.addTab(tabs.newTab().setText("연락처"));

        //탭 레이아웃에 리스너를 달아준다.
        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            //탭이 선택되었을 때때
           @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
               Log.d(TAG, "onTabSelected: " + position);

               /*if(position == 0 ){
                   getSupportFragmentManager().beginTransaction()
                           .replace(R.id.contain, fragment1).commit();
               }else if (position ==1){
                   getSupportFragmentManager().beginTransaction()
                           .replace(R.id.contain, fragment2).commit();
               }else if (position ==2){
                   getSupportFragmentManager().beginTransaction()
                           .replace(R.id.contain, fragment3).commit();
               }*/
               if(position == 0 ){
                  selFragment = fragment1;
               }else if (position ==1){
                   selFragment = fragment2;
               }else if (position ==2){
                   selFragment = fragment3;
               }else if (position ==3){
                   selFragment = fragment1;
               }else if (position ==4){
                   selFragment = fragment2;
               }else if (position ==5){
                   selFragment = fragment3;
               }else if (position ==6){
                   selFragment = fragment1;
               }else if (position ==7){
                   selFragment = fragment2;
               }else if (position ==8){
                   selFragment = fragment3;
               }
               getSupportFragmentManager().beginTransaction()
                       .replace(R.id.contain, selFragment).commit();
            }

            //탭이 선택되지 않았을 떄
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


    }
}