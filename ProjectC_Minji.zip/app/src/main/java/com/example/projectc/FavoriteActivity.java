package com.example.projectc;

import androidx.appcompat.app.AppCompatActivity;

public class FavoriteActivity extends AppCompatActivity {
    private static final String TAG = "main:FavoriteActivity";

}
