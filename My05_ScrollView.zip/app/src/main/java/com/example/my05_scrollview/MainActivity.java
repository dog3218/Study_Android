package com.example.my05_scrollview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
/*스크롤 뷰
* 화면을 넘어서는 데이터가 있을 떄 스크롤 할 수 있도록 만든 뷰
* 바로 아래의 자식태그에 하나의 위젯만 사용할 수 있다. 두개넣으면 에러 뜸*/
    ImageView imageView1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView1 = findViewById(R.id.imageView1);
        findViewById(R.id.btnChange).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imageView1.setImageResource(R.drawable.image2);
            }
        });
    }
}