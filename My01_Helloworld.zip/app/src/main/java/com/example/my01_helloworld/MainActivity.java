package com.example.my01_helloworld;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    //전역변수 btn 만들기(선언만 해줘야함)
    Button btnCall, btnNew;
    EditText editText;
    //부모 액티비티에 이미 선언된 메소드를 재정의하는 것
    @Override
    //화면을 생성해주는 메소드
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //이 액티비티는 R:res, layout:res아래 layout, activity_naim : 화면이름
       //여기서 화면 지정
        setContentView(R.layout.activity_main);

        //화면을 지정했으니 위 화면에서 정의한 위젯(버튼, 텍스트뷰 등)을 찾을 수 있다.
        //찾는타입 변수명 = findViewById(R.id.내가 지정한 아이디);
        //변수명은 xml에서 지정한 아이디와 같이 주는 게 좋다! 달라도 되긴 함
        //1.id를 이용하여 찾아서 변수에 담는다.
        //-전화번호는 숫자만 쓰므로 xml에 inputType을 number로 체크한다.

        editText = findViewById(R.id.editText);
        btnCall = findViewById(R.id.btnCall);
        //2.변수명에 클릭 리스너를 담아준다
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //editText에 있는 전화번호를 가져와서 변수에 담기
                String phoneNum = "tel:"+editText.getText().toString();
                Intent intent = new Intent(Intent.ACTION_DIAL,
                        Uri.parse(phoneNum));
            startActivity(intent);
              }
         });
        //새창띄우기: 명시적 Intent
      findViewById(R.id.btnNew).setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(), SubActivity.class);
            startActivity(intent);

          }
      });
      //main 위젯은 메인에서 sub위젯은 sub에서 찾자.
      //findViewById(R.id.btnReturn).setOnClickListener(new View.On);
    }
    //한번 클릭해보기 : 메소드 이용 ==> xml에서 지정해줌
    public void onBtnClicked(View view){
        Toast.makeText(this, "클릭한번해봤어!!",
                Toast.LENGTH_SHORT).show();
        /*context: 창을 띄울 때 자신이 가진 환경설정을 넘겨주기 위해 사용
        * -this
        * -getAplicationContext
        * -MainActivity.this
        * 3가지를 보통 사용
        * 
        * 문제: 아래쪽에 버튼을 만들어 연결하고,
        * id = btnNaer
        * text: naver.com 연결하기
        * xml에 메소드 이름을 만들어 main.java에서 메소드 완성을 한다.(단, 토스트띄울 필요 없음)*/
    }
   //네이버 연결하기 : 메소드 이용
    public void onBtnNaver(View view){
        /*화면을 띄우기 위해서는 반드시 Intent를 만들어서 안드로이드에게 줘야함
        * Intent는 암묵적 Intent와 명시적 Intent로 구분되는데
        * 암묵적 Intent는 전화걸기, 인터넷 연결, 사진찍기 등 안드로이드의
        * 내부적인 기능 사용할 때
        * 명시적 Intent는 서브화면을 만들어서 띄울 때* 필요함/
         *여기서는 암묵적 Intent를 만듬*/
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("http://m.naver.com"));
        startActivity(intent);
    }
}