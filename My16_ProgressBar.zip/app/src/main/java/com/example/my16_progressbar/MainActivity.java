package com.example.my16_progressbar;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "main:MainActivity";
    ProgressBar progressBar;
    EditText editText;
    ProgressDialog dialog;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressBar = findViewById(R.id.progressBar);
        editText = findViewById(R.id.editText);
        seekBar = findViewById(R.id.seekBar);
        
        //progress bar는 약간의 설정이 필요함
        progressBar.setIndeterminate(false);//정해진 값을 사용하는가?-아니오 false
        progressBar.setMax(100);//최대값 설정- 100
        progressBar.setProgress(20);//초기값 설정 - 20

        findViewById(R.id.btnInput).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editText.getText().toString().length()>0)
                {int num = Integer.parseInt(editText.getText().toString());
                    if(num>100){
                        num=100;
                    }

                    progressBar.setProgress(num);
                }else{
                    Toast.makeText(MainActivity.this, "숫자를 입력하세요!!", Toast.LENGTH_SHORT).show();
                }


            }
        });

        findViewById(R.id.btnshow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog = new ProgressDialog(MainActivity.this);
                dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                dialog.setMessage("파일을 불러오는 중입니다....");
                dialog.setCanceledOnTouchOutside(false);
                dialog.show();

            }
        });

        findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //여기서는 btnClose 의미 없음
                //나중에 데이터 잘 갖고 왔으면 if절 넣어서 dismiss 해주면 됨
                if(dialog  != null){
                    dialog.dismiss();//해산
                    
                }
            }
        });
        
        //SeekBar 설정
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            
            @Override                   //                 내가 번경한 값, 옮긴 주체가 유저인가?
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                editText.setText(String.valueOf(progress)); //editText는 항상 String이 들어가야함
                Log.d(TAG, "onProgressChanged: ");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}