package com.example.my26_listview1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        listView = findViewById(R.id.listView);

        //어댑터에 사용할 ArrayList 생성
        ArrayList<String> list = new ArrayList<>();

        //안드로이드에서 제공한 어댑터 생성성
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               String selItem = (String) parent.getItemAtPosition(position);
               textView.setText(selItem);
            }
        });


        list.add("볶음밥");
        list.add("탕수육");
        list.add("짜장면");
        list.add("떡볶이");
        list.add("상추튀김");
        list.add("양념치킨");
        list.add("피자");
        list.add("햄버거");
        list.add("갈비");
        list.add("갈매기살");
        list.add("삼겹살");
        list.add("부채살");
        list.add("스테이크");
        list.add("만두국");
        list.add("샐러드");
        list.add("스파게티");
        list.add("사과");

    }
}