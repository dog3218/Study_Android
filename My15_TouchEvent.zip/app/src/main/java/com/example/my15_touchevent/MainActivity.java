package com.example.my15_touchevent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    View view1, view2;
    ScrollView scrollView;
    TextView textView;

    GestureDetector detector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view1= findViewById(R.id.view1);
        view2 = findViewById(R.id.view2);
        scrollView = findViewById(R.id.scrollView);
        textView = findViewById(R.id.textView);

        view1.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                float curX = event.getX();
                float curY = event.getY();

                if(action == MotionEvent.ACTION_DOWN){
                    printString("손가락 눌림"+curX+", "+curY);
                }else if(action == MotionEvent.ACTION_MOVE){
                    printString("손가락 움직임"+curX+", "+curY);
                }else if(action == MotionEvent.ACTION_UP){
                    printString("손가락 뗌"+curX+", "+curY);
                }

                return true;
            }
        });
        //view2에 대한 터치 이벤트 : 터치 이벤트를 모션디텍션에 넘겨서
        //어떤 모션을 했는지 알려준다.
        view2.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                detector.onTouchEvent(motionEvent);


                return true;
            }
        });

        detector = new GestureDetector(this, new GestureDetector.OnGestureListener() {
           //화면이 눌렸을 때
            @Override
            public boolean onDown(MotionEvent motionEvent) {
                printString("onDown()");
                return true;
            }
            //화면이 눌렸다 떼어지는 경우
            @Override
            public void onShowPress(MotionEvent motionEvent) {
                printString("onShowPress()");
            }
            //화면이 한 손가락으로 눌렷다 떼어지는 경우
            @Override
            public boolean onSingleTapUp(MotionEvent motionEvent) {
                printString("onSingleTapUp()");
                return true;
            }
            //화면이 눌린채 일정한 속도와 방향으로 움직였다 떼는 경우
            @Override
            public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
                printString("onScroll()=> "+v+", "+v1);


                return true;
            }
            //화면을 길게 눌렀다 떼는 경우
            @Override
            public void onLongPress(MotionEvent motionEvent) {
                printString("onLongPress()");

            }
            //화면을 누른 채 가속도를 붙여 손가락을 움직였다 떼는 경우
            @Override
            public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
                printString("onFling()"+v+", "+v1);
                return true;
            }
        });
    }

    private void printString(String s) {
        textView.append(s+"\n");
        scrollView.fullScroll(View.FOCUS_DOWN);
    }

    //key가 눌렸을 때
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_BACK){
            printString("시스템에서 [Back]버튼을 누름");

            return true;
        }else if(keyCode==KeyEvent.KEYCODE_VOLUME_UP ){
            printString("시스템에서 [Volume_Up}버튼을 누름");
            return true;
        }else if(keyCode==KeyEvent.KEYCODE_VOLUME_DOWN ){
            printString("시스템에서 [Volume_Down}버튼을 누름");
            return true;
        }

        return false;

    }
}